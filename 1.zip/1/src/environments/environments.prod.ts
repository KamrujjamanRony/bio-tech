export const environment = {
    production: true,
    authKey: '0',
    viewKey: '0',
    cCode: 'b',
    DoctorApi: 'https://d.supersoftbd.com/apiA/RefDr',
    SealApi: 'https://d.supersoftbd.com/apiA/SetSeal',
    CommentApi: 'https://d.supersoftbd.com/apiA/Comment',
    AdviceApi: 'https://d.supersoftbd.com/apiA/Advice',
    MarginApi: 'https://d.supersoftbd.com/apiA/Margin',
    MainUIApi: 'https://d.supersoftbd.com/apiA/MainUI',
    CompanyApi: 'https://d.supersoftbd.com/apiA/CompanyName',
};